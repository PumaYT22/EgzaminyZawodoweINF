import FilmForm from "./components/FilmForm";

function App() {
  return (
    <div className="App">
      <FilmForm></FilmForm>
    </div>
  );
}

export default App;
